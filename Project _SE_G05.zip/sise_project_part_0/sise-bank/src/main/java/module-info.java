module pt.ulisboa.tecnico.learnjava.bank {
	exports pt.ulisboa.tecnico.learnjava.bank.services;
	exports pt.ulisboa.tecnico.learnjava.bank.domain;
	exports pt.ulisboa.tecnico.learnjava.bank.exceptions;
}