package pt.ulisboa.tecnico.learnjava.sibs.cli;

import java.util.HashMap;

public class MBWAY {

	public static HashMap<String, String> datebase = new HashMap<>();

}
