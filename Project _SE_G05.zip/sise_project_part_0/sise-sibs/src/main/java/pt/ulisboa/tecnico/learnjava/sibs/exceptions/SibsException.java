package pt.ulisboa.tecnico.learnjava.sibs.exceptions;

public class SibsException extends Exception {
	public SibsException() {
	}
}
